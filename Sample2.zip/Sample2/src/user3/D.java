package user3;

public class D {
	
	public void msg() {
		System.out.println("Hello C");
	}

}
