package privatee;

public class A {
	
	int x=20;
	private void display()
	{
		System.out.println("TNS SEssion");
	}
	public static void main(String[] args) {
		A a1=new A();
		System.out.println(a1.x);
		a1.display();
	}

}
