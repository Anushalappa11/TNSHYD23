package approach2;

public class Year {
	public static void main(String[] args) {
		Month obj=new Month();
		System.out.println(obj.x);
		obj.display();
		System.out.println(Month.y);
		Month.display1();

	}

}
