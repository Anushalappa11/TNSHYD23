package approach1;

public class Month {
	
	int x=10;
	static int y=20;
	int display() {
		return 10;
	}
	static void display1 () {
	System.out.println(10);
	}
	public static void main(String args[]) {
		Month z1=new Month();
		System.out.println(z1.x);
		z1.display();
		System.out.println(Month.y);
		Month.display1();
		
	}
}
