package defaultt;

public class A {
	
	void display()
	{
		System.out.println("Hello A");
	}

}
