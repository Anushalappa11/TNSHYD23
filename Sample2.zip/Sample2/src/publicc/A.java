package publicc;

public class A {
	
	public void display()
	{
       System.out.println("TNS session");
	}

}
