package User;

import user1.B;
import user1.C;
import user3.D;

public class A {
	
	public static void main(String[] args) {
		 B obj=new B();
		 C obj1=new C();
		 D obj2=new D();
		 
		 obj.msg();
		 obj1.msg();
		 obj2.msg();

	}

}
